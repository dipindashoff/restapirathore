package com.twitter.api;

import org.apache.http.HttpStatus;
import org.apache.http.client.utils.URIBuilder;
import org.testng.annotations.Test;


import java.net.URI;
import java.net.URISyntaxException;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class TestPOSTStatus {

    /*
    Twitter API uses OAUTH 1.0. OAuth 1.0 requires Scribe (scribejava-apis).
    oauth() accepts 4 parameters: consumerKey, consumerSecret, accessToken, secretToken
     */
    // For OAUTH 1.0
    private final String CONSUMER_KEY = "iPhFHnSrYUlOEDI3YuMbzKVhv";
    private final String CONSUMER_SECRET = "jT9p1G8aqUq0N9FlZMZvLXFEW8PqpUYOkNAT6mjtbzvwaKVTlj";
    private final String ACCESS_TOKEN = "2530365925-RdyODli9te2PYKrcNnIwMKYuuARTXL1ScZDXuBZ";
    private final String SECRET_TOKEN = "zmgkS6HQW066IXt3uXgKZ0d5wpjpGTCdIRt7yvgZBAI0v";

    // POST statuses/update
    // Resource URL: https://api.twitter.com/1.1/statuses/update.json

    @Test
    public void testPOSTUsingURI() throws URISyntaxException {

        URI postUri = null;

//        try {
         postUri = new URIBuilder()
                    .setScheme("https")
                    .setHost("api.twitter.com") // throws error when "api.twitter.com/"
                    .setPath( "/1.1/statuses/update.json" )
                    .addParameter("status", "Hello")
                    .build();
//        } catch (Exception e){
//            e.printStackTrace();
//        }
    // https://api.twitter.com/1.1/statuses/update.json?status=hello
        given().auth().oauth(CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN, SECRET_TOKEN)
                .when().post(postUri).then().assertThat().statusCode(HttpStatus.SC_OK);
    }

    @Test
    public void testPOSTUsingURLWithParams() {

        // https://api.twitter.com/1.1/statuses/update.json?status=hello



        given().auth().oauth(CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN, SECRET_TOKEN)
                .when().post("https://api.twitter.com/1.1/statuses/update.json?status=hello world").then().assertThat().statusCode(HttpStatus.SC_OK);
    }

    @Test
    public void testPOSTUsingBaseURL() {

        // https://api.twitter.com/1.1/statuses/update.json?status=hello
        baseURI = "https://api.twitter.com";
        basePath = "/1.1/statuses";


        given().auth().oauth(CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN, SECRET_TOKEN)
                .when().post("/update.json?status=hello world 2").then().assertThat().statusCode(HttpStatus.SC_OK);
    }

}
