package com.twitter.api;

import com.jayway.jsonpath.JsonPath;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class TestGET {

    // For OAUTH 1.0
    private final String CONSUMER_KEY = "iPhFHnSrYUlOEDI3YuMbzKVhv";
    private final String CONSUMER_SECRET = "jT9p1G8aqUq0N9FlZMZvLXFEW8PqpUYOkNAT6mjtbzvwaKVTlj";
    private final String ACCESS_TOKEN = "2530365925-RdyODli9te2PYKrcNnIwMKYuuARTXL1ScZDXuBZ";
    private final String SECRET_TOKEN = "zmgkS6HQW066IXt3uXgKZ0d5wpjpGTCdIRt7yvgZBAI0v";

    /*
    Get total followers of ARNIE
     */
    @Test
    public void testGET(){

        // https://api.twitter.com/1.1/followers/list.json
//        String str = given().when().post()

        baseURI = "https://api.twitter.com";
        basePath = "/1.1/followers/list.json";

        // Setup URI
        Map<String, String> map = new HashMap<>();
        map.put("screen_name", "Schwarzenegger");
        map.put("skip_status", "true");
        map.put("include_user_entities", "true");
        map.put("count", "3"); // print only 3 followers of Arnie
       String str =  given().accept(ContentType.JSON).auth().oauth(CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN,
                SECRET_TOKEN).params(map).when().get().thenReturn().asString();
        System.out.println(str);
    }

    /*
    Get name of follower with screen name, "AFaborode" (data keeps changing for every run)
     */
    @Test
    public void isFollowerOfArnie(){

        baseURI = "https://api.twitter.com";
        basePath = "/1.1/followers/list.json";

        // Setup URI
        Map<String, String> map = new HashMap<>();
        map.put("screen_name", "Schwarzenegger");
        map.put("skip_status", "true");
        map.put("include_user_entities", "true");

       Response response =  given().accept(ContentType.JSON).auth().oauth(CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN,
                SECRET_TOKEN).params(map).when().get();
        System.out.println(response.prettyPrint());
        List<String> str = JsonPath.read(response, "$..users[?(@.screen_name == 'AFaborode')].name");
        System.out.println(str);

    }

    /*
    Find count of my followers
    From when are they following me
    How many likes for each post
     */
    @Test
    public void testMyProfile(){

        // Resource URL: https://api.twitter.com/1.1/followers/ids.json

        baseURI = "https://api.twitter.com";
        basePath = "/1.1/followers/ids.json";

        // Setup URI
        Map<String, String> map = new HashMap<>();
        map.put("screen_name", "dipindashoff");

        Response response =  given().accept(ContentType.JSON).auth().oauth(CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN,
                SECRET_TOKEN).params(map).when().get();
        System.out.println(response.prettyPrint());
        String str = JsonPath.read(response, "$").toString();
        System.out.println(str);
    }
}
