package com.twitter.api;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import org.apache.http.HttpStatus;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;

import static io.restassured.RestAssured.given;

public class TestDELETE {

    // For OAUTH 1.0
    private final String CONSUMER_KEY = "iPhFHnSrYUlOEDI3YuMbzKVhv";
    private final String CONSUMER_SECRET = "jT9p1G8aqUq0N9FlZMZvLXFEW8PqpUYOkNAT6mjtbzvwaKVTlj";
    private final String ACCESS_TOKEN = "2530365925-RdyODli9te2PYKrcNnIwMKYuuARTXL1ScZDXuBZ";
    private final String SECRET_TOKEN = "zmgkS6HQW066IXt3uXgKZ0d5wpjpGTCdIRt7yvgZBAI0v";

    /*
    Delete a tweet using POST method
     */
    @Test
    public void testPostAndDeleteTweet(){
        baseURI = "https://api.twitter.com";
        basePath = "/1.1/statuses";

        // POST a Tweet
        // Get the ID of the tweet posted
        JsonPath json = given().auth().oauth(CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN, SECRET_TOKEN)
                .when().post("/update.json?status=hello world 5").thenReturn().jsonPath();
        System.out.println(json);

        String tweetID = json.getString("id");
        System.out.println(tweetID);

        // Now delete the Tweet using the POST method
        // POST statuses/destroy/:id
        // Resource URL: https://api.twitter.com/1.1/statuses/destroy/:id.json
        // Example Request:
        // POST https://api.twitter.com/1.1/statuses/destroy/240854986559455234.json

        given().accept(ContentType.JSON).auth().oauth(CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN, SECRET_TOKEN)
        .pathParam("id", tweetID).when().post("/destroy/{id}.json").then().statusCode(HttpStatus.SC_OK);
    }

}
