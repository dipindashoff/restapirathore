package DataDriven;

public class Test {

    // Use testNG
}
