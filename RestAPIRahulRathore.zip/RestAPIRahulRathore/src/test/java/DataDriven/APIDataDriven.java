package DataDriven;


import com.jayway.jsonpath.JsonPath;
import io.restassured.http.ContentType;
import static org.testng.Assert.*;

import io.restassured.response.ValidatableResponse;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static io.restassured.RestAssured.*;

public class APIDataDriven {

    /*
    Scenario:
    Create a JSON with an array of objects - this contains the request data
    Get data from JSON for 5 laptop records
    Insert new records through POST requests
    Get response of each data-set by passing query parameters(hashMap) to GET request
    And perform assertion
     */

    /*
     Create a JSON file containing an array of objects
     Pass each object as a parameter to the GET request
     Read response using JsonPath object's getters.
     Write code to calculate the expected riskScore for each data - write separate methods to calculate risk
     for each factor & calculate sumOfRisks
     Write code to validate the actual riskScore for each data from response against the sumOfRisks
     */

    @BeforeClass
    public static void init() {
        baseURI = "http://localhost";
        port = 8083;
        basePath = "/laptop-bag/webapi/api";
    }

    /*
    Return data from JSON file as a JSON String
     */
//    @Test
    public static String getJsonAsString() {
        String filePath = ".//src//test//java//DataDriven//laptop_records.json";
        try {
            // Get JSON as String
            return new String(Files.readAllBytes(Paths.get(filePath)));
        } catch (Exception e) {
            e.printStackTrace();
            return "Unable to read " + filePath + ": " + e.getMessage();
        }
    }

    /*
    Return the total size of the JSON array
     */
    public static int getJsonArraySize() {
        return JsonPath.read(getJsonAsString(), "$.length()");
    }

    @Test
    public void createNewLaptopRecords() {
        // Pass each object one after another to POST request
        String jsonString = getJsonAsString();
        // Get total records to be created
        int totalRecords = JsonPath.read(jsonString, "$.length()");
//        System.out.println(totalRecords);

        for (int i = 0; i < totalRecords; i++) {
            Map<String, ?> dataSet = JsonPath.read(jsonString, "$.[" + i + "]");
            given().accept(ContentType.JSON).contentType(ContentType.JSON).body(dataSet).when().post("/add").then().statusCode(200);
        }

        Map<String, ?> data0 = JsonPath.read(jsonString, "$.[0]");
//        data0.forEach((k,v)->System.out.println(k + " : " + v));

        // GET laptop-name of each record
        getLaptopName(jsonString, totalRecords);
    }

    public void getLaptopName(String jsonString, int totalRecords) {
        // Retrieve every record
        Map<String, ?> partialHashMap = JsonPath.read(jsonString, "$.[0].['Id', 'LaptopName']");
        partialHashMap.forEach((k, v) -> System.out.println(k + " : " + v));

        // using headers & params() -- query API not working
//        given().accept(ContentType.JSON).params(partialHashMap).when().get("/query").then().statusCode(200);
    }

    /* Query by laptop name */
    @Test
    public void queryByLaptopName() {
        // Pass each object one after another to POST request
        String jsonString = getJsonAsString();

        List<Map<String, ?>> laptopDell = JsonPath.read(jsonString, "$.[?(@.BrandName == 'Acer')]");
        given().accept(ContentType.JSON).contentType(ContentType.JSON).body(laptopDell.get(0)).when().post("/add").then().statusCode(200);

    }

}