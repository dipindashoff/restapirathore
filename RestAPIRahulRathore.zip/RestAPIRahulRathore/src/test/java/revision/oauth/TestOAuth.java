package revision.oauth;


import io.restassured.path.json.JsonPath;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;
import static org.apache.http.HttpStatus.SC_OK;
import static org.hamcrest.Matchers.*;

public class TestOAuth {

    private final String TOKEN = "65d589c0964126a9aad00b5038d40ceed10336e3";
    private final String USER_ID = "984";


    @Test
    public void testOAuthUnauthorized(){
        String str = when().get("http://coop.apps.symfonycasts.com/api/me").asString();
        System.out.println(str); //{"error":"access_denied","error_description":"an access token is required"}
    }

    @Test
    public void testOAuthGETAuthorizeUsingToken(){
        String str = given().auth().oauth2(TOKEN).when().get("http://coop.apps.symfonycasts.com/api/me").asString();
        System.out.println(str); //{"id":"984","email":"dipinxyz@gmail.com","firstName":"Dipin","lastName":"Nx"}
    }

    @Test
    public void testOAuthGETAuthorizeUsingTokenInHeaders(){
        Map<String, String> map = new HashMap<>();
        map.put("Authorization", "Bearer "+TOKEN);

        String str = given().headers(map).when().get("http://coop.apps.symfonycasts.com/api/me").asString();
        System.out.println(str); //{"id":"984","email":"dipinxyz@gmail.com","firstName":"Dipin","lastName":"Nx"}
    }

    @Test
    public void testOAuthPOSTUsingToken(){

        String str = given().auth().oauth2(TOKEN).when().post("http://coop.apps.symfonycasts.com/api/"+USER_ID+
                "/toiletseat-down").asString();
        System.out.println(str); //"You just put the toilet seat down. You\u0027re a wonderful roommate!"
    }

    @Test
    public void testOAuthPOSTUsingTokenInHeaders(){

        Map<String, String> map = new HashMap<>();
        map.put("Authorization", "Bearer "+TOKEN);

        String str = given().headers(map).when().post("http://coop.apps.symfonycasts.com/api/"+USER_ID+
                "/toiletseat-down").asString();
        System.out.println(str); //"You just put the toilet seat down. You\u0027re a wonderful roommate!"
    }

    // II GENERATE TOKENS FROM CODE
    @Test
    public void testOAuthUsingPOSTUsingCode(){
        String generatedToken = "";
        JsonPath jsonPath = given()
                .formParam("client_id","TestOAuthRestAssured")
                .formParam("client_secret", "7395a2c193f4427015f0a0926be1d6d7")
                .formParam("grant_type", "client_credentials")
                .when()
                .post("http://coop.apps.symfonycasts.com/token")
                .thenReturn()
                .jsonPath();

        generatedToken = jsonPath.getString("access_token");

        System.out.println("generatedToken: "+generatedToken);

        // GET
        String str =
                given().auth().oauth2(generatedToken).when().get("http://coop.apps.symfonycasts.com/api/me").thenReturn().asString();
        System.out.println(str);

        // POST & Assert
        // Expected: {"action":"toiletseat-down","success":true,"message":"Yea, the toilet seat is already down... you slob!","data":null}
        given().auth().oauth2(generatedToken).when().post("http://coop.apps.symfonycasts.com/api/"+USER_ID+
                        "/toiletseat-down").then().body("success", equalTo(true), "message", containsString("You just put the toilet seat down. You're a wonderful roommate!"));
    }


}
