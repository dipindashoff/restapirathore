package revision.normal;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;
import static org.apache.http.HttpStatus.SC_OK;
import static org.hamcrest.Matchers.*;


public class Revision extends BaseClassRevision {

    /* GET:
     Print using GET
     Print in JSON or XML (2 ways)
     */
    @Test
    public void testGET() {
        String str = when().get("/ping/postman").thenReturn().asString();
//               .then().assertThat().statusCode(SC_OK);
        System.out.println(str);
    }

   /*
   Given I set response type as JSON
   When I send a GET request
   Then I print the response
    */

    @Test
    public void testGETReturnJSONUsingAcceptMethod() {
        String str = given().accept(ContentType.JSON).when().get("/find/126").thenReturn().asString();
        System.out.println(str);
    }

    @Test
    public void testGETReturnXMLUsingHeadersMethod() {

        Map<String, String> map = new HashMap<>();
        map.put("Accept", "application/xml");

        String str =
                given().headers(map).when().get("/find/126").thenReturn().asString();
        System.out.println(str);
    }

    /**** Validation ****/
    /*
    Validation:
    Status Code - thenReturn() and then()
     */
    @Test
    public void testGETValidationUsingThenReturn() {
        int statusCode = when().get("/find/126").thenReturn().statusCode();
        Assert.assertEquals(statusCode, SC_OK);
    }

    @Test
    public void testGETValidationUsingThen() {

        when().get("/find/126").then().assertThat().statusCode(SC_OK);
    }

    /*
    Body:
    Hamcrest:
    String - exact & partial match
    Integer
    List of items
    Using XmlPath & assert
    Using JsonPath & assert
     */
    @Test
    public void testGETBodyValidation() {
        // Exact Match
        given().accept(ContentType.JSON).when().get("/find/126").then().body("BrandName", equalTo("Dell"));
        // Partial Match
        given().accept(ContentType.XML).when().get("/find/126").then().body("Laptop.LaptopName", containsString(
                "Latitude"));
        // Integer
        when().get("/find/126").then().body("Laptop.Id", equalTo("126"));

        // List
        // hasItem
        given().accept(ContentType.JSON).when().get("/find/126").then().body("Features.Feature", hasItem("1TB Hard " +
                "Drive"));
        // hasItems
        given().accept(ContentType.JSON).when().get("/find/126").then().body("Features.Feature", hasItems("8GB RAM",
                "1TB Hard " +
                        "Drive"));
        // Array Index
        given().accept(ContentType.JSON).when().get("/find/126").then().body("Features.Feature[0]", equalTo("8GB RAM"));
        // Using XmlPath
        String str = when().get("/find/126").thenReturn().asString();
        XmlPath xml = new XmlPath(str);
        System.out.println(xml.getString("Laptop.BrandName")); //Dell
        System.out.println(xml.getInt("Laptop.Id"));
        // Using JsonPath
        String js = given().accept(ContentType.JSON).when().get("/find/126").thenReturn().asString();
        JsonPath json = new JsonPath(js);
        // Assert String
        Assert.assertTrue(json.getString("BrandName").equalsIgnoreCase("Dell"));
        // Assert List
        Assert.assertTrue(json.getList("Features.Feature").contains("8GB RAM"));
    }

    /**** QUERY PARAMS ****/
    /*
    i. Deploy the laptop-bag.war file for 'query params'
    ii. You have to pass BOTH the parameters 'id' (& NOT 'Id') & 'laptopName' for this to work.
    iii. Do NOT use double quotes for parameter values
    e.g. http://localhost:8080/laptop-bag/webapi/api/query?id=4&laptopName=Latitude
    */
    @Test
    public void testGETUsingQueryParams() {

        String str = given().accept(ContentType.JSON)
                .param("id", "1")
                .param("laptopName", "Latitude")
                .when().get("/query").thenReturn().asString();
        System.out.println(str);
    }

    /**** POST ****/
  /*
    Json String format
    Object mapping using xm/json serialization
    Deserialization
    1. class
    2. JsonPath
   */
    @Test
    public void testPOSTUsingJsonString() {
        // Json String format
        String jsonStr = "{\"BrandName\":\"Dell\",\"Features\":{\"Feature\":[\"8GB RAM\",\"1TB Hard Drive\"]}," +
                "\"Id\":126,\"LaptopName\":\"Latitude\"}";

        given().contentType(ContentType.JSON).accept(ContentType.JSON).body(jsonStr).when().post("/add").then().assertThat().statusCode(SC_OK);
    }

    @Test
    public void testPOSTUsingObjectMapping() {

        // Generate random id
        String id = String.valueOf((int) (Math.random() * 1000));

        System.out.println("id: " + id);
        // Object Mapping
        LaptopBag bag = new LaptopBag();
        bag.setBrandName("Acer");
        Features features = new Features();
        features.setFeature(Arrays.asList("16 GB RAM", "Intel i7 Processor"));
        bag.setFeatures(features);
        bag.setId(id);
        bag.setLaptopName("Alien");

        // XML
//       given().contentType(ContentType.XML).accept(ContentType.XML).body(bag).when().post("/add").then().assertThat().statusCode(SC_OK);
        // JSON
        given().contentType(ContentType.JSON).accept(ContentType.JSON).body(bag).when().post("/add").then().assertThat().statusCode(SC_OK);
    }

    /*
    Deserialization
     1. class
     2. JsonPath
     */
    @Test
    public void deserializeIntoLaptopBag() {
        // XML
//       LaptopBag bag = given().accept(ContentType.XML).when().get("/find/126").thenReturn().as(LaptopBag.class);
//       Assert.assertEquals(bag.getBrandName(), ("Dell"));
        // JSON
        LaptopBag bag2 = given().accept(ContentType.JSON).when().get("/find/601").thenReturn().as(LaptopBag.class);
        Assert.assertTrue(bag2.getFeatures().getFeature().contains("16 GB RAM"));
    }

    @Test
    public void deserializeIntoJsonPath() {
        // JsonPath
        JsonPath jsonObj = given().accept(ContentType.JSON).when().get("/find/601").thenReturn().jsonPath();
        Assert.assertTrue(jsonObj.getList("Features.Feature").contains("16 GB RAM"));
    }

    @Test
    public void deserializeIntoXmlPath() {
        // XmlPath
        XmlPath xmlObj = given().accept(ContentType.XML).when().get("/find/601").thenReturn().xmlPath();
        Assert.assertTrue(xmlObj.getList("Laptop.Features.Feature").contains("16 GB RAM"));
    }

    /**** PUT ****/
    @Test
    public void testPUT() {
//        String id = String.valueOf((int)(1000 * Math.random()));
//        System.out.println("id: "+id);
        String jsonStr = "{\"BrandName\":\"Sommer Ray\",\"Features\":{\"Feature\":[\"8GB RAM\",\"1TB Hard Drive\"]}," +
                "\"Id\":598,\"LaptopName\":\"Insta Model\"}";
        given().accept(ContentType.JSON).contentType(ContentType.JSON).body(jsonStr).when().put("/update").then().assertThat().statusCode(SC_OK);
    }

    /**** DELETE ****/
    @Test
    public void testDELETE() {
        when().delete("/delete/0").then().assertThat().statusCode(SC_OK);
        // Verify 'item is deleted' using GET
        given().accept(ContentType.JSON).when().get("/find/0").then().assertThat().statusCode(SC_NOT_FOUND);
    }

    /**** expect() method ****/
    @Test
    public void testUsingExpectMethod() {
        expect().statusCode(SC_OK).when().get("/find/126");
    }

}
