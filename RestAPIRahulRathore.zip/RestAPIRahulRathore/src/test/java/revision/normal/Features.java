package revision.normal;

import javax.xml.bind.annotation.XmlElement;
import java.util.List;

public class Features {
    private List<String> Feature;

    @XmlElement(name = "Feature")
    public List<String> getFeature() {
        return Feature;
    }

    public void setFeature(List<String> feature) {
        Feature = feature;
    }


}
