package revision.normal;

import org.testng.annotations.BeforeClass;

import static io.restassured.RestAssured.*;

public class BaseClassRevision {

    @BeforeClass
    public static void setUp(){
        // http://localhost:8083/laptop-bag/webapi/api/find/126
        baseURI = "http://localhost";
        port = 8083;
        basePath = "laptop-bag/webapi/api";
    }

}
