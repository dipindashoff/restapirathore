package revision.ssl;

import org.testng.annotations.BeforeClass;

import static io.restassured.RestAssured.*;
import static io.restassured.authentication.CertificateAuthSettings.certAuthSettings;
import static org.apache.http.HttpStatus.*;
import static org.hamcrest.Matchers.*;

public class BaseClassSSLAuth {

    @BeforeClass
    public void setUp(){

        baseURI = "https://localhost";
        port = 8443;
        baseURI = "/laptop-bag/webapi/sslres";
        authentication = certificate("C:\\Program Files\\Java\\jdk1.8.0_131\\bin\\mykey.keystore", "password");
    }
}
