package revision.ssl;

import io.restassured.http.ContentType;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.*;
import static org.hamcrest.Matchers.*;

public class TestSSLAuth extends BaseClassSSLAuth {

    /**
     * SSL certificates
     * 0. Unauthorised access
     * 1. Bypassing SSL
     * 2. Supply certificate
     */

    @Test
    public void testSSLUnAuthorised(){
       String str =
               given().accept(ContentType.JSON).when().get("https://localhost:8443/laptop-bag/webapi/sslres/all")
                       .thenReturn().asString();
        System.out.println(str); // Error: Unable to find valid certification path to requested target
    }

    @Test
    public void testSSLBypassAuthorization(){
        String str =
                given().log().all().relaxedHTTPSValidation().accept(ContentType.JSON)
                        .when().get("https://localhost" +
                        ":8443" +
                        "/laptop-bag" +
                "/webapi" +
                "/sslres" +
                "/all").thenReturn().asString();
        System.out.println(str);
    }

    @Test
    public void testUsingSSLCertificate(){
        String str =
                given().log().all().auth().certificate("C:\\Program Files\\Java\\jdk1.8.0_131\\bin\\mykey.keystore", "password")
                        .accept(ContentType.JSON).when().get("https" +
                        "://localhost" +
                        ":8443" +
                        "/laptop-bag" +
                        "/webapi" +
                        "/sslres" +
                        "/all").thenReturn().asString();
        System.out.println(str);
    }

    // After base class setup
    @Test
    public void testUsingSSLCertificateAfterSetupMethod(){

        /** NOT WORKING ONLY WHEN USING BASE CLASS SETUP :'( **/
        String str =
                given().log().everything().when().get("/all").thenReturn().asString();
        System.out.println(str);
    }


}
