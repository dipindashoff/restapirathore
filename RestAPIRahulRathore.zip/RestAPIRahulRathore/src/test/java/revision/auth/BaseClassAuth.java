package revision.auth;

import org.testng.annotations.BeforeClass;


import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.*;
import static org.hamcrest.Matchers.*;


public class BaseClassAuth {

    // http://localhost:8083/laptop-bag/webapi/secure/all
    @BeforeClass
    public void setUp(){
        baseURI = "http://localhost";
        port = 8083;
        basePath = "/laptop-bag/webapi/secure";
        authentication = preemptive().basic("admin", "welcome");
    }
}
