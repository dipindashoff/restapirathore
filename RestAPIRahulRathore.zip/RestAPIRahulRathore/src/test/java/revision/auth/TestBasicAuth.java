package revision.auth;

import io.restassured.http.ContentType;
import org.apache.commons.codec.binary.Base64;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.*;
import static org.hamcrest.Matchers.*;

public class TestBasicAuth extends BaseClassAuth {

    /*
    Test unauthorized entry
    Pass username/password using headers
    Pass username/password using auth() methods:
       i Test no entry for Challenged authorization
       ii  Green light for Basic Pre-emptive Authorization
     */

    // Test unauthorized entry
    @Test
    public void testUnauthEntry(){
        given().accept(ContentType.JSON).when().get("http://localhost:8083/laptop-bag/webapi/secure/all").then().assertThat().statusCode(SC_UNAUTHORIZED);
    }

    // Pass username/password using headers
    @Test
    public void testGET(){
        String encryptedStr =  new String(Base64.encodeBase64("admin:welcome".getBytes()));
        Map<String, String> map = new HashMap<>();
        map.put("Authorization", "Basic "+encryptedStr);
        given().log().all().accept(ContentType.XML).headers(map).when().get("/all").then().assertThat().statusCode(SC_OK);
    }

    // Pass username/password using auth() (Basic Challenged) method - fails
    @Test
    public void testGETUsingBasicAuthChallengeMethod(){
        given().log().all().accept(ContentType.XML).auth().basic("admin", "welcome").when().get("/all").then()
                .assertThat().statusCode(SC_OK);
    }

    // Pass username/password using auth() (Basic Pre-emptive) method
    @Test
    public void testGETUsingBasicAuthPreemptiveMethod(){
        given().log().all().accept(ContentType.XML).auth().preemptive().basic("admin", "welcome").when().get("/all")
                .then().assertThat().statusCode(SC_OK);
    }

    // After Base class setup
    public void setUp(){
        baseURI = "http://localhost";
        port = 8083;
        basePath = "/laptop-bag/webapi/secure";
        authentication = preemptive().basic("admin", "welcome");
    }
    @Test
    public void testGETUsingBasicAuthPreempetiveAfterBaseClassSetUp(){
        setUp(); // Call setup here directly
        String str =
                given().accept(ContentType.JSON).when().get("/all").thenReturn().asString();
    }

}
