package myRest.api.oauth;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class TestOAuth {

    private static final String OAUTH_TOKEN = "12fc362a25d5d3c632067754ca0aecaa4bbe2b7e";
    private static final String USER_ID = "984";


    /**
     * Generate access tokens from
     * 1. UI
     * 2. Code (if it's applicable)
     */

    /* I. GENERATE TOKENS FROM UI */

    /* GET REQUEST */
    /*
    When I access URL without access token
    Then access denied error should appear
     */
    @Test
    public void testGetOAuthWithNoAccessTokenFail(){

        String str = when().get("http://coop.apps.symfonycasts.com/api/me").asString();
        System.out.println(str); //{"error":"access_denied","error_description":"an access token is required"}
    }

    /*
    Given I provide access token
    When I access URL
    Then my details should appear
     */
    @Test
    public void testGetOAuthWithAccessTokenPass(){

        String str = given().auth().oauth2(OAUTH_TOKEN).when().get("http://coop.apps.symfonycasts.com/api/me").asString();
        System.out.println(str);
    }

    /* POST REQUEST */
    /*
    Given I provide access token
    When I send a POST request using OAUTH method
    Then the response should appear
     */
    @Test
    public void testPostOAuthWithAccessToken(){

        String str =
                given().auth().oauth2(OAUTH_TOKEN).when().post("http://coop.apps.symfonycasts.com/api/"+USER_ID+
                        "/toiletseat-down").asString();
        System.out.println(str);
    }

    /*
    Given I provide access token
    When I send a POST request using headers method
    Then the response should appear
     */
    @Test
    public void testPostOAuthWithAccessTokenInHeaders(){

        Map<String, String> map = new HashMap<>();
        map.put("Authorization", "Bearer "+OAUTH_TOKEN);

        String str =
                given().headers(map).when().post ("http://coop.apps.symfonycasts.com/api/"+USER_ID+"/toiletseat-down").asString();
        System.out.println(str);
    }

    /* II. GENERATE TOKENS FROM CODE */
    /*
    URL: POST /token  http://coop.apps.symfonycasts.com/token
    The endpoint used for requesting an access token, using either the authorization_code or client_credentials grant type.
    This accepts the following POST fields:
    i. client_id ii. client_secret iii. grant_type
     */

    private String oauthToken;
    @BeforeClass
    public void generateOAuthToken(){

        baseURI = "http://coop.apps.symfonycasts.com";

        System.out.println("Generating token...");

        JsonPath json =  given()
                .formParam("client_id", "TestOAuthRestAssured")
                .formParam("client_secret", "7395a2c193f4427015f0a0926be1d6d7")
                .formParam("grant_type", "client_credentials")
                .when().post("http://coop.apps.symfonycasts.com/token").thenReturn().jsonPath();
        oauthToken = json.getString("access_token");

        System.out.println("New Token: "+oauthToken);

    }
    @Test
    public void testPostUsingGeneratedToken(){

        String str =
                given().auth().oauth2(oauthToken).when().post("/api/"+USER_ID+"/toiletseat-down").asString();
        System.out.println(str);
        // Expected Output
//        {"action":"toiletseat-down","success":true,"message":"You just put the toilet seat down.
//        You're a wonderful roommate!","data":null}

        given().auth().oauth2(oauthToken).when().post("/api/"+USER_ID+"/toiletseat-down")
                .then().assertThat().body("action", containsString("toiletseat-down"));
    }

    /**
     * Given I use the custom generated oauth token
     * When I try to access a URL outside my scope
     * Then it should throw access denied message
     */
    @Test
    public void testPostInvalidScope(){
        String str = given().auth().oauth2(oauthToken).when().post("http://coop.apps.symfonycasts.com/api/"+USER_ID+
                "/eggs-collect").asString();
        System.out.println(str);

        given().auth().oauth2(oauthToken).when().post("http://coop.apps.symfonycasts.com/api/"+USER_ID+"/eggs-collect")
                .then().body("error", equalToIgnoringCase( "insufficient_scope"));
    }

}
