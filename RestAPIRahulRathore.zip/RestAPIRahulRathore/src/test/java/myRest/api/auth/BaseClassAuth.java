package myRest.api.auth;

import org.testng.annotations.BeforeClass;

import static io.restassured.RestAssured.*;

public class BaseClassAuth {
    /*
    Setup Rest Assured Environment variables
     */
    @BeforeClass // setUP() will be first executed when BaseClass is loaded into memory
    public static void setUp() {

        baseURI = "http://localhost";
        basePath = "/laptop-bag/webapi/secure";
        port = 8083;
        authentication = preemptive().basic("admin", "welcome");
    }
}

