package myRest.api.auth;

import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.*;
import static org.hamcrest.Matchers.*;

public class TestAuthenticationGetMethod  extends BaseClassAuth {

    // New Secure URI: http://localhost:8080/laptop-bag/webapi/secure/find/{id}
//    extends BaseClass

    /* AUTHENTICATION USING HEADER*/

    /**
     * Given I expect a Status Code of 401 Unauthorized error
     * When I send a GET request to a secured URI
     * And no authorization values
     */
    @Test
    public void testGetWithoutAuth(){

//        expect().log().all().statusCode(SC_OK).when().get("http://localhost:8083/laptop-bag/webapi/secure/all");
        expect().log().all().statusCode(SC_UNAUTHORIZED).when().get("/all");
    }

    /**
     * Given I pass authorization username and password via Headers
     * When I send a GET request to a secured URI
     * Then it should return 200 OK
     */
    @Test
    public void testGetAuthUsingHeaders(){

        String encryptedPassword = EncryptionUtility.encryptPassword("admin:welcome");

        // Use headers to pass authorization username and password
        Map<String, String> authorization = new HashMap<>();
//        authorization.put("Authorization", "Basic YWRtaW46d2VsY29tZQ==");
        authorization.put("Authorization", "Basic "+"encryptedPassword");
        given().log().all().headers(authorization).when().get("/all").then().assertThat().statusCode(SC_OK);
    }

    /**
     * Given I pass authorization username and password using Rest Assured CHALLENGED basic auth methods
     * When I send a GET request to a secured URI
     * Then it should return a 401 Unauthorised error
     */
    @Test
    public void testGetAuthUsingRestAssuredFailScenario(){

        // Use Rest Assured methods to pass authorization username and password
        given().auth().basic("admin", "welcome").when().get("/all").then().assertThat().statusCode(SC_UNAUTHORIZED);

        /**
         * NOTE:
         * 2 basic authentication methods in Rest Assured
         * i) Pre-emptive: Always sends username and password along with the request
         * ii) Challenged: Sends username and password only when Server asks for it
         * This laptop bag application does not support challenged authentication method. That's why it returned a 401
         * unauthorized error
         */
    }

    /**
     * Given I pass authorization username and password using Rest Assured PRE-EMPTIVE basic auth methods
     * When I send a GET request to a secured URI
     * Then it should return 200 OK
     */
    @Test
    public void testGetAuthUsingRestAssuredPassScenario(){

        // Use Rest Assured pre-emptive methods to pass authorization username and password
        expect().statusCode(SC_OK).given().auth().preemptive().basic("admin", "welcome").log().all().when().get("/find" +
                "/126");
    }

    /* Setting up the environment for authentication */
    /**
     * Given I set up environment containing authorization username and password
     * When I send a GET request to a secured URI
     * Then it should return 200 OK
     */
    @Test
    public void testGetAuthAfterEnvironmentSetup(){

        // Pre-emptive methods to pass authorization username and password are supplied by BaseClass
        expect().statusCode(SC_OK).given().when().get("/find" +
                "/126");
    }


}
