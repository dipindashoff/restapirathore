package myRest.api.ssl;

import io.restassured.http.ContentType;
import myRest.api.helper.BaseClass;
import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.SC_OK;
import static org.hamcrest.Matchers.*;

public class TestGetSSL {

    /* Handling SSL secured URls */

    /*
    SSL URL: http://localhost:8443/laptop-bag/webapi/sslres/

    1. Fails without SSL handling
    2. Bypass certificate checks
    3. Supply valid certificate along with request
     */

    /*
    Given I accept content type as JSON
    When I send a GET request to a SSL URL
    Then it should return a certificate error
     */
    @Test
    public void testGetForSSLConnectionFailScenario(){

//        int status = when().get("http://localhost:8443/laptop-bag/webapi/sslres/all").thenReturn().statusCode();
//        System.out.println(status);

        String s =
                given().accept(ContentType.JSON).when().get("http://localhost:8443/laptop-bag/webapi/sslres/all").thenReturn().asString();
        System.out.println(s);
    }

    /*
    Given I accept content type as JSON
    And I bypass certificate
    When I send a GET request to a SSL URL
    Then it should return with status code 200 OK
     */
    @Test
    public void testGetForSSLConnectionBypassCertificate(){

        // Bypass SSL method
        // given() -> Request Specification -> relaxedHTTPSValidation()
        // This means that you'll trust all hosts regardless if the SSL certificate is invalid.

        // ISSUES:
        // In $tomcat/conf/server.xml--> Update sslProtocol="SSLv3" from sslProtocol="TLS"
        // Use this URL: https://localhost:8443/laptop-bag/webapi/sslres/all
        // In Postman, to bypass SSL validation, Menu--File--Settings--SSL certificate verification--Disable

      given().relaxedHTTPSValidation().accept(ContentType.JSON).when().get("https://localhost:8443/laptop-bag/webapi/sslres/all").then().assertThat().statusCode(SC_OK);
    }

    /*
    Given I accept content type as JSON
    And I supply certificate
    When I send a GET request to a SSL URL
    Then it should return with status code 200 OK
     */
    @Test
    public void testGetForSSLConnectionSupplyCertificate(){

        given().auth().certificate("<keystore location>", "password").accept(ContentType.JSON).when().get("http" +
                "://localhost:8443/laptop" +
                "-bag/webapi/sslres/all").then().assertThat().statusCode(SC_OK);
    }
}
