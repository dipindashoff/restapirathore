package myRest.api.helper;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class TestGetMethod extends BaseClass {

    /* WRITING GET METHOD */
    /* Setup using the RestAssured environment variable */

    /*
    A simple GET request

    When I send a GET request
    Then I print the response as string
     */
    @Test
    public static void testGetPrintDefaultResponse() {
        // pass the URL directly if baseURI, port and basePath are not set
//        String url = "http://localhost:8083/laptop-bag/webapi/api/ping/postman"; //Hi! postman
//        String url = "http://localhost:8083/laptop-bag/webapi/api/all"; // print All data in XML
//        System.out.println(when().get(url).asString());
        // After baseURI, port and basePath are set
        System.out.println(when().get("/all").asString());

        // NOTE:
        // Use asString() and not toString()
        // String str = given().accept(ContentType.XML).when().get("/find/126")
        // .toString();
        //→ using toString() method throws error; it prints an object value like ‘io.restassured.internal
        // .RestAssuredResponseImpl@555cf22’.
    }
    /* HANDLING RESPONSE */
    /*
    Set response content to JSON using given()

    Given I set response content type in JSON format
    When I send a GET request
    Then I print the response in JSON
     */
    @Test
    public static void testGetPrintResponseInJSON() {

        // METHOD 1
        Response response1 = given().accept(ContentType.JSON).when().get("/find/126");
        System.out.println(response1.asString());

        /* Creating the GET request with custom headers */
        // METHOD 2 Custom Header similar to Postman->Headers->Presets
        Map<String, String> headers = new HashMap<>();
        headers.put("Accept", "application/json");
        Response response2 = given().headers(headers).when().get("/find/126");
        System.out.println(response2.asString());
    }

    /* Handling and Validating the response status code */

    /*
  Validate Status Code from response using thenReturn() and then()

  Given I set response content type in JSON format
  When I send a GET request
  Then I verify if Status Code is 200 OK
    */
    @Test
    public static void testStatusCode() {

        // Validating the Status Code using thenReturn()
        // 1. Get Status Code using thenReturn() -- lacks native assert method
        int statusCode = given().accept(ContentType.JSON).when().get("/all").thenReturn().statusCode(); //thenReturn()
        System.out.println("statusCode: " + statusCode);

        // 2. Validate the status code using TestNG assert()
        Assert.assertEquals(statusCode, HttpStatus.SC_OK); // 200 PASS
//        Assert.assertEquals(statusCode, HttpStatus.SC_BAD_REQUEST); // 400 FAIL

        // OR
        // Validating the Status Code using then() - it has it's built-in assert method
        given().accept(ContentType.JSON).when().get("/all").then().assertThat().statusCode(HttpStatus.SC_OK);

        // Inference
        // To return/print status code or body use thenReturn()
        // To validate status code or body content use then().assertThat()
    }

    /*
   Filter Search by valid id & validate Status Code using then()
   And print response body using thenReturn()

  Given I set response content type in JSON format
  When I send a GET request for a valid id
  Then I verify if Status Code is 200 OK
  And I print the response body
    */
    @Test
    public static void testGetForID() {
        System.out.println(baseURI+":"+port+basePath);
        // Assert the Status Code
        given().accept(ContentType.JSON).when().get("/find/126").then().assertThat().statusCode(HttpStatus.SC_OK);

        // Print the response body
//        String body = given().accept(ContentType.JSON).when().get("find/126").asString(); //OR use below
        String body = given().accept(ContentType.JSON).when().get("find/126").thenReturn().body().asString();
        System.out.println(body);
    }

    /*
  Filter Search by invalid id & validate Status Code = 404

  Given I set response content type in JSON format
  When I send a GET request for an invalid id
  Then I verify if Status Code is 404 Not Found
    */
    @Test
    public static void testGetForInvalidID() {
        given().accept(ContentType.JSON).when().get("/find/1").then().assertThat().statusCode(HttpStatus.SC_NOT_FOUND);
    }

    /*
    How to do Postman->request Header->Presets

 Given I set presets in request Header to JSON/XML/text (text is invalid)
 When I send a GET request for a valid id
 Then I print the response body
   */
    @Test
    public static void testGetUsingCustomHeader() {

        // given() ->return type RequestSpecification
        // interface RequestSpecification is implemented by class RequestSpecificationImpl
        // class RequestSpecificationImpl has a method called headers(Map<String,?> headers)

        // JSON
        // Postman->Request Header->Presets->Key:Accept, Value:application/json
        Map<String, String> headers1 = new HashMap<>();
        headers1.put("Accept", "application/json");
        String body1 = given().headers(headers1).when().get("find/126").thenReturn().body().asString();
        System.out.println(body1);

        // XML
        // Postman->Request Header->Presets->Key:Accept, Value:application/xml
        Map<String, String> headers2 = new HashMap<>();
        headers2.put("Accept", "application/xml");
        String body2 = given().headers(headers2).when().get("find/126").thenReturn().body().asString();
        System.out.println(body2);

        // text --- INVALID throws "HTTP 406 Not Acceptable" error
        // Postman->Request Header->Presets->Key:Accept, Value:application/xml
        Map<String, String> headers3 = new HashMap<>();
        headers3.put("Accept", "application/text");
        String body3 = given().headers(headers3).when().get("find/126").thenReturn().body().asString();
        System.out.println(body3);
    }

    /*
  Validate response content using Hamcrest libraries

  Given I set response content type in JSON format
  When I send a GET request for a valid id
  Then I verify if the BrandName equals or contains "Dell"
    */
    @Test
    public static void testValidateResponseContentPass() {
        // Rest Assured uses Hamcrest framework for validation similar to JUnit
        // We use assert for validating Status Code. Similarly we can use methods in Hamcrest classes for
        // response validation
        // So perform static import - import static org.hamcrest.Matchers.*;
        // IntelliJ-->Open External Libraries-->org.hamcrest-->class Matchers
        // ctrl+f12-->equals-->equalToCompressingWhiteSpace to compare 2 strings ignoring case

        // Exact match
        given().accept(ContentType.JSON).when().get("/find/126").then()
                .body("BrandName",equalToCompressingWhiteSpace("Dell"),
                        "Id",equalTo(126),
                        "LaptopName",equalToCompressingWhiteSpace("Latitude"));

        // Partial match - using contains
        given().accept(ContentType.JSON).when().get("/find/126").then()
                .body("BrandName",containsString("Dell"));
    }

    /*
  Validate response content - fail scenario

  Given I set response content type in JSON format
  When I send a GET request for an id
  Then I verify if error is thrown for an invalid BrandName
   */
    @Test
    public static void testValidateResponseContentFail() {

//        java.lang.AssertionError: 1 expectation failed.
//        JSON path BrandName doesn't match.
//        Expected: a string equal to "Dell1" compressing white space
//        Actual: Dell

        given().accept(ContentType.JSON).when().get("/find/126").then()
                .body("BrandName",equalToCompressingWhiteSpace("Dell1"));
    }

    /*
    Validate the list contents in response body
    --> using hasItem, hasItems, hasSize methods in Matchers class

    Given I set response content type to JSON
    When I send a GET request
    Then I validate the contents of the list from inside a nested JSON object
     */
    @Test
    public static void testListContentsInJSON(){

        /* Sample JSON*/
//        {
//            "BrandName": "Dell",
//            "Features": {
//              "Feature": [
//                  "8GB RAM",
//                  "1TB Hard Drive"
//            ]
//        },
//            "Id": 126,
//            "LaptopName": "Latitude"
//        }

        // Validate 1 item from a list
        given().accept(ContentType.JSON).when().get("/find/126").then().body("Features.Feature", hasItem("8GB RAM"));

        // Validate more items from a list
        given().accept(ContentType.JSON).when().get("/find/126").then().body("Features.Feature", hasItems("8GB RAM", "1TB Hard Drive"));

        // Negative Scenario -- passing invalid values throws error
//        given().accept(ContentType.JSON).when().get("/find/126").then().body("Features.Feature", hasItems("GB RAM", "1TB"));

        // Validate the size of the list
        given().accept(ContentType.JSON).when().get("/find/126").then().body("Features.Feature", hasSize(2));
        // Negative Scenario: Validate the size of the list -- invalid size throws error
        given().accept(ContentType.JSON).when().get("/find/126").then().body("Features.Feature", hasSize(3));
    }

    /*
   Validate the list contents in XML in response body

   Given I set response content type to XML
   When I send a GET request
   Then I validate the contents of the XML
    */
    @Test
    public static void testResponseListContentsInXML(){

        /* Sample XML*/
//        <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
//        <Laptop>
//            <BrandName>Dell</BrandName>
//            <Features>
//                <Feature>8GB RAM</Feature>
//                <Feature>1TB Hard Drive</Feature>
//            </Features>
//            <Id>126</Id>
//            <LaptopName>Latitude</LaptopName>
//        </Laptop>

        // Validate contents of XML
        given().accept(ContentType.XML).when().get("/find/126").then().body("Laptop.BrandName", equalTo("Dell"),
                "Laptop.LaptopName", equalTo("Latitude"));

        // Negative Scenario -- passing invalid values throws error
        given().accept(ContentType.XML).when().get("/find/126").then().body("Laptop.BrandName", hasItems("Not Dell"));

        // Using the and() method
        given().accept(ContentType.XML).when().get("/find/126").then().body("Laptop.BrandName", equalTo("Dell"))
                .and().body("Laptop.Features.Feature", hasItem("8GB RAM"));

        // Validate contents of list in XML
//        given().accept(ContentType.XML).when().get("/find/126").then().body("Laptop.Features.Feature", hasItem("8GB RAM"));
    }

    /* Validation using XmlPath class */

/*
    Given I set response content type to XML
    When I send a GET request
    Then I print the contents of the XML using XmlPath class
    And validate the contents
 */
    @Test
    public void testContentXMLPath(){

        String str = given().accept(ContentType.XML).when().get("/find/126").asString();
        // Create XmlPath object
        XmlPath xml = new XmlPath(str);

        // Print using XmlPath class object
        // --> Print string
        System.out.println(xml.getString("Laptop.BrandName"));
        System.out.println(xml.getString("Laptop.LaptopName"));
        // --> Print integer
        System.out.println(xml.getInt("Laptop.Id"));
        // --> Print List
        xml.getList("Laptop.Features.Feature").forEach(System.out::println);

        // Validate using JUnitAssert
        // --> Assert string
        String brandName = xml.getString("Laptop.BrandName");
        Assert.assertEquals(brandName, "Dell");
        // --> Assert List of items
        List<String> listOfFeatures = xml.getList("Laptop.Features.Feature");
        Assert.assertTrue(listOfFeatures.contains("8GB RAM"));
    }

    /* Validation using JsonPath class */
    /*
    Given I set response content type to JSON
    When I send a GET request
    Then I print the contents of the JSON using JsonPath class
    And validate the contents
    */
    @Test
    public void testContentJsonPath(){

        String str = given().accept(ContentType.JSON).when().get("/find/126").asString();
        // Create XmlPath object
        JsonPath json = new JsonPath(str);

        // Print using XmlPath class object
        // --> Print string
        System.out.println(json.getString("BrandName"));
        System.out.println(json.getString("LaptopName"));
        // --> Print integer
        System.out.println(json.getInt("Id"));
        // --> Print List
        json.getList("Features.Feature").forEach(System.out::println);

        // Validate using JUnitAssert
        // --> Assert string
        String brandName = json.getString("BrandName");
        Assert.assertEquals(brandName, "Dell");
        // --> Assert List of items
        List<String> listOfFeatures = json.getList("Features.Feature");
        Assert.assertTrue(listOfFeatures.contains("8GB RAM"));
    }

    /*
   Laptop Bag
   queryParam
   E.g, http://localhost:8080/laptop-bag/webapi/api/query?id="1"&laptopName="Dell"

    NOTE:
    i. Deploy the laptop-bag.war file for 'query params'
    ii. You have to pass BOTH the parameters 'id' (& NOT 'Id') & 'laptopName' for this to work.
    iii. Do NOT use double quotes for parameter values
            e.g. http://localhost:8080/laptop-bag/webapi/api/query?id=4&laptopName=Latitude

    Handling the Query Parameters

    Given I set response content type to JSON
    And id as 126
    And LaptopName as "Latitude"
    When I send GET request
    Then I validate if response content as id as 126
    And LaptopName as "Latitude"
     */
    @Test
    public void testQueryParams(){
        String str = given().accept(ContentType.JSON)
                .param("id", "126")
                .param("laptopName", "Latitude")
                .when().get("/query").thenReturn().asString();
        System.out.println(str);
    }

}
