package myRest.api.helper;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Laptop")
public class LaptopBag {

//    @XmlElement(name = "BrandName") // throws exception
    private String brandName;
    private Features feature;
    private String id;
    private String LaptopName;

//    @XmlElement(name = "BrandName")
    public String getBrandName() {
        return brandName;
    }
    @XmlElement(name = "BrandName") // no change in effect
    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    @XmlElement(name = "Features")
    public Features getFeature() {
        return feature;
    }
    public void setFeature(Features feature) {

        this.feature = feature;
    }

    @XmlElement(name = "Id")
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getLaptopName() {
        return LaptopName;
    }
    @XmlElement(name = "LaptopName")
    public void setLaptopName(String laptopName) {
        LaptopName = laptopName;
    }
}
