package myRest.api.helper;

import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;

public class Features {

    private List<String> features;

    public Features(){

        features = new ArrayList<>();
    }

    public List<String> getFeatures() {

        return features;
    }
    @XmlElement(name = "Feature")
    public void setFeatures(List<String> features) {

        this.features = features;
    }
}
