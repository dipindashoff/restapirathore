package myRest.api.helper;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class TestPostMethod extends BaseClass {

    /*
    Create new data using POST method

    Given I accept content type as JSON
    With content type JSON
    And request body of type JSON String
    When I make a POST request
    Then I validate if Status Code equals 200 OK
    And I validate response id

    Convert JSON to String
    https://tools.knowledgewalls.com/jsontostring
     */
    @Test
    public void testPostBodyAsJSONString(){

//        System.out.println(RandomStringUtils.random(3, false,true));
        int id = (int) (1000 * Math.random());


        String data = "{\"BrandName\":\"Hewlett\",\"Features\":{\"Feature\":[\"88GB RAM\",\"1TB Hard Drive\"]}," +
                "\"Id\":"+id+",\"LaptopName\":\"Packard\"}";
        given().accept(ContentType.JSON).with().contentType(ContentType.JSON).and().body(data).when().post("/add").then().assertThat().statusCode(HttpStatus.SC_OK).body("Id", equalTo(id));

        // Without the syntactic  sugar
        given().accept(ContentType.JSON).contentType(ContentType.JSON).body(data).when().post("/add").then().assertThat().statusCode(HttpStatus.SC_OK).body("Id", equalTo(id));
    }

    /*
    Sending POST request without body will return a 400 error (bad request)
     */
    @Test
    public void testPostWithoutBody(){

        String id = (int) (1000 * Math.random()) + "";

        given().accept(ContentType.JSON).with().contentType(ContentType.JSON).when().post("/add").then().assertThat().statusCode(HttpStatus.SC_BAD_REQUEST);
    }

    /**
     * POST method using Object Mapping
     *
     * Given I accept response of type XML
     * And I send data as an XML object
     * When I make a POST request
     * Then I validate the status code
     * And also the LaptopName
     */
    @Test
    public void testPostUsingObjectMapping(){

        // Pass Laptop object into request body
        // Create a Laptop class
        // As it has a nested Features object, create a Features object
        // Add serialization annotations to avoid exception below:
        // unable to marshal type "myRest.api.helper.LaptopBag" as an element because it is
        // missing an @XmlRootElement annotation
        // Also, add 'jackson-dataformat-xml' dependency
        // Add logs to see what's going on behind the scenes

        String id = (int)(1000* Math.random()) + "";
        LaptopBag laptop = new LaptopBag();
        laptop.setBrandName("Mc Kenzie");
        Features features = new Features();
        features.setFeatures(Arrays.asList("10GB RAM", "3TB HDD"));
        laptop.setFeature(features);
        laptop.setId(id);
        laptop.setLaptopName("Juice");

        // Request Type = XML; Response Type = XML
//        given().log().headers().log().body().accept(ContentType.XML).contentType(ContentType.XML).body(laptop)
//                .when().post("/add").then().assertThat().statusCode(HttpStatus.SC_OK)
//                .body("Laptop.Id", equalTo(id));
//        // Request Type = XML; Response Type = JSON
//        given().log().headers().log().body().accept(ContentType.JSON).contentType(ContentType.XML).body(laptop)
//                .when().post("/add").then().assertThat().statusCode(HttpStatus.SC_OK)
//                .body("Id", equalTo(Integer.parseInt(id)));
//        // Request Type = JSON; Response Type = JSON
        given().log().headers().log().body().accept(ContentType.JSON).contentType(ContentType.JSON).body(laptop)
                .when().post("/add").then().assertThat().statusCode(HttpStatus.SC_OK)
                .body("Id", equalTo(Integer.parseInt(id)));
        // Request Type = JSON; Response Type = XML
//        given().log().headers().log().body().accept(ContentType.JSON).contentType(ContentType.XML).body(laptop)
//                .when().post("/add").then().assertThat().statusCode(HttpStatus.SC_OK)
//                .body("Id", equalTo(Integer.parseInt(id)));
    }

    /**
     * Deserialization
     *
     * Given I accept response of type XML
     * When I make a GET request
     * Then it should return a class object
     * And I assert the object contents
     */
    @Test
    public void testDeserializationLaptopObject(){

        // Response is an object of class Laptop
        // For converting response body into class objects,
        // use thenReturn().as(Class<T> aClass) method
        // E.g. as(LaptopBag.class) returns Laptop object
        // Use Assert & getter methods for validation of object contents

        // Response Type = XML
        LaptopBag object = given().accept(ContentType.XML).when().get("/find/126").thenReturn().as(LaptopBag.class);
        Assert.assertTrue(object.getBrandName().equals("Dell"));
        // Assert list
        Assert.assertTrue(object.getFeature().getFeatures().contains("8GB RAM"), "Entry Not Found");
        // Negative scenario
        Assert.assertTrue(object.getFeature().getFeatures().contains("not 8GB RAM"), "Entry Not Found");

        // Response Type = JSON
        LaptopBag object2 = given().accept(ContentType.JSON).when().get("/find/127").thenReturn().as(LaptopBag.class);
        Assert.assertTrue(object2.getBrandName().equals("HP"));
    }

    /**
     * Deserialization
     *
     * Given I accept response of type JSON
     * When I make a GET request
     * Then it should return a JsonPath object
     * And I assert the JsonPath object contents
     */
    @Test
    public void testDeserializationJsonPathObject(){

        JsonPath jsonObj = given().accept(ContentType.JSON).when().get("/find/126").thenReturn().jsonPath();
        Assert.assertTrue(jsonObj.getString("BrandName").equals("Dell"));
        Assert.assertTrue(jsonObj.getList("Features.Feature").contains("8GB RAM"));
    }

    /**
     * Deserialization
     *
     * Given I accept response of type XML
     * When I make a GET request
     * Then it should return an XmlPath object
     * And I assert the XmlPath object contents
     */
    @Test
    public void testDeserializationXmlPathObject(){

        XmlPath xmlObj = given().accept(ContentType.XML).when().get("/find/126").thenReturn().xmlPath();
        Assert.assertTrue(xmlObj.getString("Laptop.BrandName").equals("Dell"));
        Assert.assertTrue(xmlObj.getList("Laptop.Features.Feature").contains("8GB RAM"));
    }

}
