package myRest.api.helper;

import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

public class BaseClass {
    /*
    Setup Rest Assured Environment variables
     */
    @BeforeClass // setUP() will be first executed when BaseClass is loaded into memory
    public static void setUp() {

        baseURI = "http://localhost";
        basePath = "/laptop-bag/webapi/api";
        port = 8083;
    }
}

