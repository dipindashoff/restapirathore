package myRest.api.helper;

import io.restassured.http.ContentType;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.*;
import static org.hamcrest.Matchers.*;

public class TestPutMethod extends BaseClass {

    /**
     * Update an existing record
     *
     * Given I accept JSON content
     * And my content is JSON
     * When I perform a POST request to add content
     * And I update the data using PUT request
     * Then I validate status Code
     * And the modified content
     */
    @Test
    public void testPut(){

        // Add record
        LaptopBag bag = new LaptopBag();
        bag.setBrandName("HP");
        Features feature = new Features();
        feature.setFeatures(Arrays.asList("16TB HDD"));
        bag.setFeature(feature);
        bag.setId((int) (1000*(Math.random()))+"");
        bag.setLaptopName("450s");

        given().log().body().accept(ContentType.JSON).and().contentType(ContentType.JSON).and().body(bag).when().post(
                "/add");

        // Update record -- update feature & LaptopName
        feature.setFeatures(Arrays.asList("16TB HDD", "This is a PUT method"));
        bag.setFeature(feature);
        bag.setLaptopName("Updated LaptopName");

        given().log().body().accept(ContentType.JSON).and().contentType(ContentType.JSON).and().body(bag).when().put("/update")
                .then().assertThat().statusCode(SC_OK).body("Features.Feature", hasItem("This is a PUT method"));
    }

}
