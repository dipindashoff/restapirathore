package myRest.api.helper;

import io.restassured.http.ContentType;
import org.testng.annotations.Test;

import java.util.Arrays;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.*;
import static org.hamcrest.Matchers.*;

public class TestDeleteMethod extends BaseClass{

    /**
     * Delete an entry
     *
     * Given I add a new data using POST request
     * And I update the contents using PUT request
     * When I send a DELETE request for that ID
     * Then the Status Code should be 200 OK
     */
    @Test
    public void testDeleteMethod(){

        String id = (int) (1000*(Math.random()))+"";

        // Add record to delete later
        LaptopBag bag = new LaptopBag();
        bag.setBrandName("Microsoft");
        bag.setId(id);
        Features features = new Features();
        features.setFeatures(Arrays.asList("1 GB RAM", "14' screen"));
        bag.setFeature(features);
        bag.setLaptopName("Old Laptop");

        // POST
        given().log().body().accept(ContentType.JSON).contentType(ContentType.JSON).and().body(bag).when()
                .post("/add").then().statusCode(SC_OK);

        // Update contents
        features.setFeatures(Arrays.asList("This is a PUT method"));
        bag.setFeature(features);

        given().accept(ContentType.JSON).contentType(ContentType.JSON).and().body(bag).when()
                .put("/update").then().statusCode(SC_OK);

        // Now I delete this entry
        when().delete("/delete/"+id).then().assertThat().statusCode(SC_OK);

        // A GET request to this ID should now return a 404 Not Found
        when().get("/find/"+id).then().statusCode(SC_NOT_FOUND);

        // Negative Scenario - delete an invalid entry - it returns a 404
//        when().delete("/delete/1400").then().assertThat().statusCode(SC_OK);
    }

    /**
     * Delete an entry
     *
     * Given I add a new data using POST request
     * I expect Status Code to be 200 OK
     * When I delete a record
     * And I expect Status Code as 404 Not Found
     * When I make a GET request to this ID
     */
    @Test
    public void testDeleteMethodUsingExpect(){

        String id = (int) (1000*(Math.random()))+"";

        // Add record to delete later
        LaptopBag bag = new LaptopBag();
        bag.setBrandName("Microsoft");
        bag.setId(id);
        Features features = new Features();
        features.setFeatures(Arrays.asList("1 GB RAM", "14' screen"));
        bag.setFeature(features);
        bag.setLaptopName("Old Laptop");

        // POST
        given().log().body().accept(ContentType.JSON).contentType(ContentType.JSON).and().body(bag).when()
                .post("/add").then().statusCode(SC_OK);

        // I expect status Code as 200 OK when I delete this entry
        expect().statusCode(SC_OK).when().delete("/delete/"+ id);
        // a GET request should throw a 404 Not Found
        expect().statusCode(SC_NOT_FOUND).when().get("/find/"+ id);
    }

}
