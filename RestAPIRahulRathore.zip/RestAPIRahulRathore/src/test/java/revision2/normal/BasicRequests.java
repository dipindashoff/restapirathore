package revision2.normal;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.SC_NOT_FOUND;
import static org.apache.http.HttpStatus.SC_OK;
import static org.hamcrest.Matchers.*;

public class BasicRequests extends BaseClass {


    /**** GET ****/
    @Test
    /* A Simple Ping Request */
    public void pingRequest() {
        when().get("/ping/postman").then().statusCode(200);
        String response = when().get("/ping/postman").thenReturn().asString();
        System.out.println(response);
    }

    @Test
    /* Set response content 1 pf 2 */
    public void testGETReturnJSONUsingHeadersMethod() {

//        Map<String, String> map = new HashMap<>();
//        map.put("Accept", "application/xml");

        Map map = new HashMap<>();
        map.put("Accept", "application/json");
        String response = given().headers(map).when().get("/all").asString();
        System.out.println(response);
    }

    @Test
    /* Set response content 2 pf 2 */
    public void testGETReturnJSONUsingAcceptMethod() {
        String response = given().accept(ContentType.XML).when().get("/all").thenReturn().asString();
        System.out.println(response);
    }

    @Test
    /* validate status code - 2 ways */
    public void validateStatusCode() {
        // Using thenReturn()
        int statusCode = when().get("/all").thenReturn().statusCode();
        Assert.assertEquals(statusCode, 200);

        // Using then()
        when().get("/all").then().statusCode(200);
    }

    @Test
    /* validate response body using Hamcrest matchers, XmlPath and JsonPath */
    public void validateBody() {
        // exact match - BrandName
        given().accept(ContentType.JSON).when().get("/find/1").then().body("BrandName", equalToCompressingWhiteSpace(
                "Dell"));
        // partial match - Laptop.LaptopName
        given().accept(ContentType.XML).when().get("/find/1").then().body("Laptop.BrandName", containsString("Del"));
        // integer
        given().accept(ContentType.JSON).when().get("/find/1").then().body("Id", equalTo(1));
        // List
        // hasItem
        given().accept(ContentType.JSON).when().get("/find/1").then().body("Features.Feature", hasItem("8GB RAM"));
        // hasItems
        given().accept(ContentType.JSON).when().get("/find/1").then().body("Features.Feature", hasItems("8GB RAM",
                "1TB Hard Drive"));
        // array index
        given().accept(ContentType.JSON).when().get("/find/1").then().body("Features.Feature[0]", equalTo("8GB RAM"));
        // size
        given().accept(ContentType.JSON).when().get("/find/1").then().body("Features.Feature", hasSize(2));
        // all validations together -- adv: soft assert
        given().accept(ContentType.JSON).when().get("/find/1").then().body("BrandName", equalToCompressingWhiteSpace(
                "Dell"), "Id", equalTo(1), "Features.Feature", hasItem("8GB RAM"));
        // using XmlPath
        String xmlResponse = given().accept(ContentType.XML).when().get("/find/1").thenReturn().asString();
        XmlPath xml = new XmlPath(xmlResponse);
        System.out.println(xml.getString("Laptop.BrandName"));
        System.out.println(xml.getInt("Laptop.Id"));
        System.out.println(xml.getList("Laptop.Features.Feature"));
        // using JsonPath
        String response = given().accept(ContentType.JSON).when().get("/find/1").thenReturn().asString();
        JsonPath jsonResponse = new JsonPath(response);
        Assert.assertEquals(jsonResponse.getString("BrandName"), "Dell");
        Assert.assertEquals(jsonResponse.getInt("Id"), 1);
        Assert.assertTrue(jsonResponse.getList("Features.Feature").contains("8GB RAM"));
    }

    @Test
    /* using QUERY PARAMS */
    /*
    i. Deploy the laptop-bag.war file for 'query params'
    ii. You have to pass BOTH the parameters 'id' (& NOT 'Id') & 'laptopName' for this to work.
    iii. Do NOT use double quotes for parameter values on POSTMAN
    e.g. http://localhost:8083/laptop-bag/webapi/api/query?id=1&laptopName=Latitude
    */
    public void passingQueryParams() {
        // using headers & params()
        Map map = new HashMap<>();
        map.put("id", "1");
        map.put("laptopName", "Latitude");
        given().accept(ContentType.JSON).params(map).when().get("/query").then().statusCode(200);

        // using param()
        String str = given().accept(ContentType.JSON)
                .param("id", "1")
                .param("laptopName", "Latitude")
                .when().get("/query").thenReturn().asString();
        System.out.println(str);
    }

    /**** POST ****/
    @Test
    /* POST request using a JSON string */
    public void postUsingJsonString() {
        String jsonStr = "{\"BrandName\":\"Lenovo\",\"Features\":{\"Feature\":[\"20GB RAM\",\"500GB Hard Drive\"]},\"Id\":3,\"LaptopName\":\"Latitude\"}";
        given().accept(ContentType.JSON).contentType(ContentType.JSON).body(jsonStr).when().post("/add").then().statusCode(200);
    }

    @Test
    /* Using logs - headers and body */
    public void usingLogs() {
        String jsonStr = "{\"BrandName\":\"ABC\",\"Features\":{\"Feature\":[\"12GB RAM\",\"10GB Hard Drive\"]}," +
                "\"Id\":5,\"LaptopName\":\"Dum\"}";
        given().accept(ContentType.XML).contentType(ContentType.JSON).body(jsonStr).log().body().log().headers().when().post(
                "/add").then().statusCode(200).log().body();
    }

    @Test
    /* Using POJO object */
    public void postPOJOObject() {
        String id = String.valueOf((int) (Math.random() * 1000));
        System.out.println(id);

        LaptopBag laptopBag = new LaptopBag();
        laptopBag.setBrandName("BP2L");
        Features feature = new Features();
        feature.setFeature(Arrays.asList("10GB RAM", "10 TB SSD"));
        laptopBag.setFeatures(feature);
        laptopBag.setId("5");
        laptopBag.setLaptopName("DEEHS");

//        given().log().body().contentType(ContentType.JSON).accept(ContentType.JSON).body(laptopBag).when().post("/add").then().statusCode(SC_OK);
        given().log().body().contentType(ContentType.XML).accept(ContentType.JSON).body(laptopBag).when().post("/add").then().statusCode(SC_OK);
    }

    @Test
    /* Deserialization */
    public void deserialization() {
        // class object
        LaptopBag obj = given().accept(ContentType.JSON).when().get("/find/1").thenReturn().as(LaptopBag.class);
        Assert.assertTrue(obj.getBrandName().equals("Dell"));
        LaptopBag obj2 = given().accept(ContentType.XML).when().get("/find/4").thenReturn().as(LaptopBag.class);
        Assert.assertTrue(obj2.getBrandName().equals("BPL"));

        // Json object
        JsonPath jsonPath = given().accept(ContentType.JSON).when().get("/find/1").thenReturn().jsonPath();
        System.out.println(jsonPath.getString("BrandName"));
    }

    /**** PUT ****/
    @Test
    /* using PUT */
    public void putRequest() {
        LaptopBag laptopBag = new LaptopBag();
        laptopBag.setBrandName("BPL2");
        Features feature = new Features();
        feature.setFeature(Arrays.asList("5GB RAM", "10 TB SSD"));
        laptopBag.setFeatures(feature);
        laptopBag.setId("5");
        laptopBag.setLaptopName("DEEHS2");
        given()
                .accept(ContentType.JSON)
                .contentType(ContentType.JSON)
                .body(laptopBag)
        .when()
                .put("/update")
        .then()
                .body("BrandName", equalTo("BPL2"), "Features.Feature", hasItems("5GB RAM", "10 TB SSD")
                        , "LaptopName", equalTo("DEEHS2"));

    }

    /**** DELETE ****/
    public void deleteRecord() {
        when().delete("/delete/5").then().statusCode(SC_OK);
        expect().statusCode(SC_NOT_FOUND).when().get("/find/5");
    }

    /**** ROOT PATH ****/
    @Test
    public void useRootPath(){
        given()
                .accept(ContentType.XML)
        .when()
                .get("/find/1")
        .then()
                .rootPath("Laptop")
                .body("BrandName", equalToCompressingWhiteSpace(
                "Dell"));
    }

    /**** Request and Response Specifications ****/
    @Test
    public void useRequestAndResponseSpec(){

        // get() URI using 'find' URI
        given().accept(ContentType.JSON).when().get("/find/1").prettyPrint();
        // The get() URI using PATH PARAMETER
        // http://localhost:8083/laptop-bag/webapi/api/find/{id}
        given().accept(ContentType.JSON).pathParam("id", "1").when().get("/find/{id}").prettyPrint();


        RequestSpecification reqSpec = new RequestSpecBuilder()
                .setAccept(ContentType.JSON)
                .addPathParam("id", "1")
                .build();
        ResponseSpecification respSpec = new ResponseSpecBuilder()
                .expectContentType(ContentType.JSON)
                .expectStatusCode(SC_OK)
                .expectBody("BrandName", equalTo("Dell"))
                .build();

        given()
                .spec(reqSpec)
        .when()
                .get("/find/{id}")
        .then()
                .spec(respSpec);

    }

    /**** Using AND in between multiple validations ****/
    @Test
    /* validate response body using Hamcrest matchers, XmlPath and JsonPath */
    public void validateBodyUsingAnd() {

        given()
                .accept(ContentType.JSON)
        .when()
                .get("/find/1")
        .then()
                .statusCode(SC_OK)
        .and()
                .body("BrandName", equalToCompressingWhiteSpace("Dell"))
        .and()
                .body("Id", equalTo(1))
        .and()
                .body("Features.Feature", hasItem("8GB RAM"));
    }
}
