package revision2.normal;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Laptop")
public class LaptopBag {

//    {
//        "BrandName": "Dell",
//            "Features": {
//              "Feature": [
//                  "8GB RAM",
//                  "1TB Hard Drive"
//	            ]
//          },
//        "Id": 1,
//        "LaptopName": "Latitude"
//    }

    private String brandName;
    private Features features;
    private String id;
    private String laptopName;

    @XmlElement(name = "BrandName")
    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }
    public String getBrandName() {
        return brandName;
    }

    @XmlElement (name = "Features")
    public void setFeatures(revision2.normal.Features features) {
        this.features = features;
    }
    public Features getFeatures() {
        return features;
    }

    @XmlElement (name = "Id")
    public void setId(String id) {
        this.id = id;
    }
    public String getId() {
        return id;
    }

    @XmlElement (name = "LaptopName")
    public void setLaptopName(String laptopName) {
        this.laptopName = laptopName;
    }
    public String getLaptopName() {
        return laptopName;
    }

}
