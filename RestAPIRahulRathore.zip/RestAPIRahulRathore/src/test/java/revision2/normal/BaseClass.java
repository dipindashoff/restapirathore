package revision2.normal;

import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class BaseClass {

    @BeforeClass
    public void setUp(){
        baseURI = "http://localhost";
        port = 8083;
        basePath = "/laptop-bag/webapi/api";
    }

}
