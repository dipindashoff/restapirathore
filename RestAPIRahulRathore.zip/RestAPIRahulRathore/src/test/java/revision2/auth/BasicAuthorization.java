package revision2.auth;

import io.restassured.http.ContentType;
import org.apache.commons.codec.binary.Base64;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.SC_OK;

public class BasicAuthorization {

    // Same .war file but different URL

//    @BeforeMethod
    public void init(){
        // http://localhost:8083/laptop-bag/webapi/secure/all
        baseURI = "http://localhost/";
        port = 8083;
        basePath = "/laptop-bag/webapi/secure";
    }

    @BeforeMethod
    public void initWithAuth(){
        baseURI = "http://localhost/";
        port = 8083;
        basePath = "/laptop-bag/webapi/secure";
        authentication = preemptive().basic("admin", "welcome");
    }

    @Test
    /* Without authentication */
    public void sendUnauthorizedGetRequest(){
        when().get("/all").then().statusCode(SC_OK);
    }

    @Test
    /* Using Basic Authorization - preemptive */
    public void postUsingBasicAuth(){
        String jsonStr = "{\"BrandName\":\"Lenovo\",\"Features\":{\"Feature\":[\"20GB RAM\",\"500GB Hard Drive\"]},\"Id\":3,\"LaptopName\":\"Latitude\"}";
        given()
                .accept(ContentType.JSON)
                .contentType(ContentType.JSON)
                .body(jsonStr)
                .auth()
                .preemptive()
                .basic("admin", "welcome")
                .when()
                .post("http://localhost:8083/laptop-bag/webapi/secure/add")
                .then()
                .statusCode(200);
    }

    @Test
    public void getRequestUsingBasicAuthMethod(){
        given()
                .accept(ContentType.JSON)
                .auth()
                .preemptive()
                .basic("admin", "welcome")
                .when()
//                .get("http://localhost:8083/laptop-bag/webapi/secure/all")
                .get("/all")
                .then()
                .statusCode(200);
    }

    @Test
    /* Using Headers */
    public void getRequestUsingHeaders(){
        String encryptedUserCreds  = new String(Base64.encodeBase64("admin:welcome".getBytes()));
        Map map = new HashMap<>();
        map.put("Authorization", "Basic " + encryptedUserCreds);
        expect()
                .statusCode(SC_OK)
                .given()
                .accept(ContentType.JSON)
                .headers(map)
                .when()
                .get("/all");
    }

    @Test
    /* Using certificate from initWithAuth() */
    public void passingAuthDetailsFromInit(){
        when()
                .get("/find/1")
                .then()
                .statusCode(SC_OK);
    }
}
