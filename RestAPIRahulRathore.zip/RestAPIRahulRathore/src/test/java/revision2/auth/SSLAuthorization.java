package revision2.auth;

import io.restassured.http.ContentType;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.*;
import static org.hamcrest.Matchers.*;

public class SSLAuthorization {

//    @BeforeMethod
    public void init(){
        // https://localhost:8443/laptop-bag/webapi/sslres/all
        baseURI = "https://localhost";
        port = 8443;
        basePath = "/laptop-bag/webapi/sslres";
    }

    @BeforeMethod
    public void initWithAuth(){
        baseURI = "https://localhost/";
        port = 8443;
        basePath = "/laptop-bag/webapi/sslres";
        authentication = certificate("C:\\Program Files\\Java\\jdk1.8.0_131\\bin\\mykey.keystore", "password");
    }

    @Test
    /* throws error for unauthorized entry */
    public void unauthorizedEntry(){
        given()
                .accept(ContentType.JSON)
                .when()
                .get("/all")
                .then()
                .statusCode(SC_OK);
        // throws 'unable to find valid certification path to requested target'
    }

    @Test
    /* bypass SSL validation */
    public void bypassSSLValidation(){
        given()
                .relaxedHTTPSValidation()
                .when()
                .get("/all")
                .then()
                .statusCode(SC_OK);
    }

    @Test
    /* pass SSL certificate */
    public void passSSLCertificate(){
        given()
                .accept(ContentType.JSON)
                .auth()
                .certificate("C:\\Program Files\\Java\\jdk1.8.0_131\\bin\\mykey.keystore", "password")
                .when()
                .get("/find/1")
                .then()
                .body("BrandName", equalTo("Dell"));
    }

    @Test
    /* Using certificate from initWithAuth() */
    public void passingSSLCertFromInit(){
        when()
                .get("/find/1")
                .then()
                .statusCode(SC_OK);
    }

}
