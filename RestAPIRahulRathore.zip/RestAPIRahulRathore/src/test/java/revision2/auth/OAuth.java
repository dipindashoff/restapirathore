package revision2.auth;

import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.*;
import static org.apache.http.HttpStatus.*;
import static org.hamcrest.Matchers.*;

public class OAuth {

    // Generate a new token from UI
    private final String TOKEN = "1eb2588f74c7d7f0736b4128ea90d44bd12740b6";
    private final String USER_ID = "984";


    @Test
    /* make unauthorized entry */
    public void unauthorizedEntry(){
        String str = given()
                .accept(ContentType.JSON)
                .when()
                .get("http://coop.apps.symfonycasts.com/api/me")
                .asString();
        System.out.println(str);
        // "error":"access_denied"
    }

    /*** Use TOKEN from UI ***/
    @Test
    /* Send oauth token generated from UI as authorization*/
    public void getRequestUsingTokenFromUI(){
        Response response = given()
                .auth()
                .oauth2(TOKEN)
                .when()
                .get("http://coop.apps.symfonycasts.com/api/me");

        System.out.println(response.asString());

        response.then()
                .body("firstName", equalTo("Dipin"));
    }

    @Test
    /* Send oauth token generated from UI as authorization*/
    public void usingHeaders(){
        Map map = new HashMap<>();
        map.put("Authorization", "Bearer "+ TOKEN);
        given()
                .headers(map)
                .when()
                .post("http://coop.apps.symfonycasts.com/api/"+ USER_ID +"/eggs-collect")
                .then()
                .body("message", containsString("eggs have been collected"));
    }

    /*** Generate TOKEN from code ***/
    @Test
    /* Generate and extract token using API */
    public void generateToken(){
        // Extract Token
        JsonPath jsonPath = given()
                .param("client_id", "TestOAuthRestAssured")
                .param("client_secret", "7395a2c193f4427015f0a0926be1d6d7")
                .param("grant_type", "client_credentials")
                .when()
                .post("http://coop.apps.symfonycasts.com/token")
                .thenReturn()
                .jsonPath();
        String token = jsonPath.getString("access_token") ;

        given()
                .auth()
                .oauth2(token)
                .when()
                .get("http://coop.apps.symfonycasts.com/api/me")
                .then()
                .body("firstName", equalTo("Dipin"));
    }



}
