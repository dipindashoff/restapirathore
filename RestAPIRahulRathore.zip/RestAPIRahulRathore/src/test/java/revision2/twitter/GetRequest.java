package revision2.twitter;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.*;

public class GetRequest {

    // https://api.twitter.com/1.1/followers/list.json

    static final String CONSUMER_KEY = "iPhFHnSrYUlOEDI3YuMbzKVhv";
    static final String CONSUMER_SECRET = "jT9p1G8aqUq0N9FlZMZvLXFEW8PqpUYOkNAT6mjtbzvwaKVTlj";
    static final String ACCESS_TOKEN = "2530365925-RdyODli9te2PYKrcNnIwMKYuuARTXL1ScZDXuBZ";
    static final String SECRET_TOKEN = "zmgkS6HQW066IXt3uXgKZ0d5wpjpGTCdIRt7yvgZBAI0v";
    Map<String, String> paramMap;

    @BeforeClass
    public void init() {
        baseURI = "https://api.twitter.com";
        basePath = "/1.1/followers/list.json";
        authentication = oauth(CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN, SECRET_TOKEN);

        paramMap = new HashMap<>();
        paramMap.put("screen_name", "@dipindashoff");
//        paramMap.put("count", "10"); //defaults to 20; max up to 200
        paramMap.put("skip_status", "true");
        paramMap.put("include_user_entities", "false");

        RestAssured.requestSpecification = new RequestSpecBuilder().
                addParams(paramMap).build();
    }

    @Test
    /* Get my followers */
    public void getFollowers() {
        given()
                .accept(ContentType.JSON)
//                .params(paramMap)
                .when()
                .get()
                .thenReturn()
                .prettyPrint();
    }

    @Test
    /*Check if BalaH is my follower
    And get his followers count*/
    public void getNameFromID() {
//        given().when().get().then().body("users.screen_name", hasItem("Hbalatweets")).statusCode(SC_OK);
        String followerName = given().when().get().then().extract().path("users.find{it.screen_name " +
                "== " +
                "'Hbalatweets'}.name");
        Assert.assertTrue(followerName.equals("Balasubramaniam H"));
        int followersCount = given().when().get().then().extract().path("users.find{it.name == 'Balasubramaniam H'}" +
                ".followers_count");
        System.out.println("Bala's followers: "+ followersCount);
    }

    @Test
    /*
    Find count of my followers
    From when are they following me
    How many likes for each post
     */
    public void getFollowersCount(){
        int size = when().get().then().extract().path("users.size");
        System.out.println("Total followers: " + size);
    }
}
