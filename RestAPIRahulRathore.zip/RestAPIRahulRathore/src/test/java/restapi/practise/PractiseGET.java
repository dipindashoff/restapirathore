package restapi.practise;

import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import myRest.api.helper.BaseClass;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.*;

public class PractiseGET extends BaseClass {

    // Import the 2 static imports
    // Set Env variables in BaseClass

    // Ping postman
    @Test
    public void test0(){

        String str = when().get("/ping/postman").thenReturn().asString();
        System.out.println(str);
    }

    // A simple GET request that prints the response
    @Test
    public void test1(){
        String str = when().get("/find/126").asString();
        System.out.println(str);
    }

    // Set response content to JSON using 2 methods
    @Test
    public void test2(){
        // Method 1
        String str = given().accept(ContentType.JSON).when().get("/find/126").asString();
        System.out.println(str);

        // Method 2
        Map<String, String> map = new HashMap<>();
        map.put("Accept", "application/json");
        String str2 = given().headers(map).when().get("/find/126").thenReturn().asString();
        System.out.println(str2);
    }

    // Validate status code using thenReturn() & then()
    @Test
    public void test3(){
        // thenReturn()
        int actual1 = when().get("/find/126").thenReturn().statusCode();
        Assert.assertEquals(actual1, HttpStatus.SC_OK);
        // then()
        when().get("/find/126").then().assertThat().statusCode(HttpStatus.SC_OK);
    }

    // Validation JSON response content using Hamcrest libraries
    @Test
    public void test4(){

        // Exact match = BrandName
        given().accept(ContentType.JSON).when().get("/find/126").then().body("BrandName",
                equalToCompressingWhiteSpace("Dell"));
        // Partial Match = BrandName
        given().accept(ContentType.JSON).when().get("/find/126").then().body("BrandName",
                containsString("Dell"));
        // Id
        given().accept(ContentType.JSON).when().get("/find/126").then().body("Id",
                equalTo(126)); // pass integer
        // Validating list
        // Features
        given().accept(ContentType.JSON).when().get("/find/126").then().body("Features.Feature",
                hasItems("8GB RAM", "1TB Hard Drive"));
        // All 3 Clubbed together
        given().accept(ContentType.JSON).when().get("/find/126").then().body("BrandName",
                equalToCompressingWhiteSpace("Dell"), "Id",
                equalTo(126), "LaptopName", equalToCompressingWhiteSpace("Latitude"));
        // Validate size of list
        given().accept(ContentType.JSON).when().get("/find/126").then().body("Features.Feature",
                hasSize(2));
    }

    // Validation XML response content using Hamcrest libraries
    @Test
    public void test5(){

        when().get("/find/126").then().body("Laptop.BrandName",
                equalToCompressingWhiteSpace("Dell"));

        when().get("/find/126").then().body("Laptop.Id", equalTo("126"));

        when().get("/find/126").then().body("Laptop.Features.Feature",
                hasItems("8GB RAM", "1TB Hard Drive"));
    }

    // Validation using XmlPath class
    @Test
    public void test6(){
        String str = when().get("/find/126").thenReturn().asString();
        XmlPath xml = new XmlPath(str);

        System.out.println(xml.getString("Laptop.BrandName"));
        Assert.assertEquals(xml.getString("Laptop.BrandName"), "Dell");
        System.out.println(xml.getInt("Laptop.Id"));
        System.out.println(xml.getList("Laptop.Features.Feature"));
        Assert.assertTrue(xml.getList("Laptop.Features.Feature").contains("8GB RAM"));
    }

    // Add query parameters and validate the response body
    @Test
    public void test7(){
        System.out.println(given().accept(ContentType.JSON).param("Id", "126").when()
                .get("/query").thenReturn().asString());
    }


    @Test
    public void testQueryPra() {

        /**
         * Given Accept the content in JSON format
         * And ID as 75
         * And Laptop Name as Latitude S Series
         * When I perform the GET Request
         * Then Status code 200 OK should be returned
         * And The response content should have id as 75
         * And Feature list should contain 1024 GB of SSD
         */

        given()
                .accept(ContentType.JSON)
                .param("Id", "126")
                .param("laptopName", "Latitude")
                .when()
                .get("/query")
                .then()
                .assertThat()
                .statusCode(HttpStatus.SC_OK)
                .and()
                .assertThat()
                .body("Features.Feature", hasItem("8GB RAM"));
    }

}
