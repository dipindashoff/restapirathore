package restapi.practise;

import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;

public class Features {

    private List<String> Feature;

//    public Features(){
//        Feature = new ArrayList<>();
//    }
    @XmlElement(name="Feature")
    public List<String> getFeature() {
        return Feature;
    }

    public void setFeature(List<String> feature) {
        Feature = feature;
    }

}
