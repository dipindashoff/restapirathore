package restapi.practise;

import io.restassured.http.ContentType;
import myRest.api.helper.BaseClass;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

public class PractisePOST extends BaseClass {

    // POST request using a JSON string
    // Also use logs
    @Test
    public void test1(){
        String id = (int) (1000 * (Math.random())) + "";

        String json = "{\"BrandName\":\"Alienware\",\"Features\":{\"Feature\":[\"15.6' 144hz FHD Display\",\"Intel " +
                "Core i7-9750H\",\"NVIDIA RTX 2060 6GB\"]},\"Id\":"+id+",\"LaptopName\":\"M15 Gaming Laptop\"}";

        given().log().body().contentType(ContentType.JSON).body(json).when().post("/add").then()
                .assertThat().statusCode(HttpStatus.SC_OK);
    }

    // POST using Object Mapping
    @Test
    public void test2(){
        String id = (int)(1000 * (Math.random())) + "";

        Laptop laptop = new Laptop();
        laptop.setBrandName("Lenovo");
        Features feature = new Features();
        feature.setFeature(Arrays.asList("i7-8565U 1.8GHz", "16GB RAM"));
        laptop.setFeatures(feature);
        laptop.setId(id);
        laptop.setLaptopName("HP Spectre x360 2019 13T Gemcut");

        given().log().body().accept(ContentType.XML).contentType(ContentType.JSON).body(laptop).when()
                .post("/add").then().assertThat().statusCode(HttpStatus.SC_OK);
    }

    // Deserialization
    @Test
    public void test3(){

        Laptop laptop = when().get("/find/355").thenReturn().as(Laptop.class);
        Assert.assertTrue(laptop.getBrandName().equals("Lenovo"));
    }

}
